package model

type Violation string
